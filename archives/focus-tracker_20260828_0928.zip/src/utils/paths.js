const USE_PROJECT_PATH = true;
const PROJECT_LOG_PATH = 'C:\\Users\\rober\\Documents\\focus-tracker';

function getBasePath(app) {
  return USE_PROJECT_PATH ? PROJECT_LOG_PATH : app.getPath('userData');
}

module.exports = {
  getBasePath,
};